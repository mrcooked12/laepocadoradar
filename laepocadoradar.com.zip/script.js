
const games = {
  shooters: [
    { name: "Counter Strike 1.6", link: "https://www.mediafire.com/file/1/cs16.exe" },
    { name: "Halo CE", link: "https://www.mediafire.com/file/2/haloce.exe" }
  ],
  terror: [
    { name: "Slendytubbies", link: "https://www.mediafire.com/file/3/slendy.exe" },
    { name: "Five Nights at Freddy's 1", link: "https://www.mediafire.com/file/4/fnaf1.exe" }
  ],
  aventura: [
    { name: "GTA San Andreas", link: "https://www.mediafire.com/file/5/gtasa.zip" },
    { name: "Bully", link: "https://www.mediafire.com/file/6/bully.zip" }
  ]
};

function showSection(section) {
  const container = document.getElementById('game-section');
  container.innerHTML = '';
  games[section].forEach(game => {
    const gameDiv = document.createElement('div');
    gameDiv.className = 'game';
    gameDiv.innerHTML = `<h3>${game.name}</h3><a href="${game.link}" target="_blank">Descargar</a>`;
    container.appendChild(gameDiv);
  });
}
